import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message readIdFromUrlPath(Message message) {

       //get url 
       def map = message.getHeaders();
       def url = map.get("CamelHttpUrl");

       //split url
       String[] vUrl;
       vUrl = url.split('/');
       int size = vUrl.length;
       
       //get id
       message.setProperty('productId', vUrl[size-1]);
       
       return message;
}